# FoodSense_AI-Powered-Smart-Food-Donation-Platform
FoodLink connects surplus food with NGOs and volunteers, ensuring no food goes to waste while many are fed. With real-time matching, fast pickups, and transparent tracking, it creates an efficient food redistribution system. FoodLink turns waste into opportunity, directly advancing Zero Hunger and reducing poverty.
