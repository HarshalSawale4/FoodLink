<?php
echo "FoodLink is working!";
?>
